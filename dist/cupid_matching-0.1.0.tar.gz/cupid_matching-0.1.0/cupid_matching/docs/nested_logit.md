## `nested_logit` module

::: cupid_matching.nested_logit
