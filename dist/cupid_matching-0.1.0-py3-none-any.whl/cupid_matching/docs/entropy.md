# `entropy` module
::: cupid_matching.entropy
