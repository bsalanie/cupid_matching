# `min_distance` module

::: cupid_matching.min_distance
