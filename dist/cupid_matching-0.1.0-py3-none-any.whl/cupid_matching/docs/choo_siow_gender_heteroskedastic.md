# `choo_siow_gender_heteroskedastic` module

::: cupid_matching.choo_siow_gender_heteroskedastic
