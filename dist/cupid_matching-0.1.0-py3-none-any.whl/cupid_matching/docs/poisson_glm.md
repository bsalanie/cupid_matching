# `poisson_glm` module

::: bs_cupid_try.poisson_glm
