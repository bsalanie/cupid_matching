# `choo_siow_heteroskedastic` module

::: cupid_matching.choo_siow_heteroskedastic
