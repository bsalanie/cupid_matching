# `model_classes` module

::: cupid_matching.model_classes
