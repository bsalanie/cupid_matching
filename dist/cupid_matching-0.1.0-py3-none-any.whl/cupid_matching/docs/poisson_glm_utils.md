# `poisson_glm_utils` module

::: bs_cupid_try.poisson_glm_utils
